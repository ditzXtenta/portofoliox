import { commentsHandler } from '../server/api-handlers.js';

export const config = { api: { bodyParser: { sizeLimit: '4mb' } } };
export default commentsHandler;
