import { adminCommentsHandler } from '../../server/api-handlers.js';
export default adminCommentsHandler;
