import { useCallback, useEffect, useRef, useState } from "react";

const SPOTIFY_EMBED_URL =
  "https://open.spotify.com/embed/playlist/6IVSqu5z6fwknHLj0JcnNE?utm_source=generator&si=dc170b8cb16b49b8";

const projects = [
  {
    number: "01",
    title: "Beruang",
    subtitle: "Financial Planner",
    category: "WEB APP",
    description:
      "Aplikasi pengelolaan keuangan untuk mencatat pemasukan, pengeluaran, dan memantau kondisi keuangan.",
    image: "/images/beruang.png",
    imageAlt: "Tampilan aplikasi Beruang Financial Planner",
    demo: "https://beruang-livid.vercel.app/",
    stack: ["HTML", "CSS", "JavaScript"],
  },
  {
    number: "02",
    title: "Payment",
    subtitle: "Payment Website",
    category: "WEB APP",
    description:
      "Website pembayaran dengan tampilan modern untuk menyajikan informasi pembayaran dengan praktis.",
    image: "/images/payment.png",
    imageAlt: "Tampilan website Payment",
    demo: "https://allpayrdc.vercel.app",
    stack: ["HTML", "CSS", "JavaScript"],
  },
  {
    number: "03",
    title: "Our Gallery",
    subtitle: "Digital Gallery",
    category: "WEBSITE GALERI",
    description:
      "Galeri digital untuk menampilkan koleksi foto dengan tata letak yang rapi dan responsif.",
    image: "/images/our-gallery.png",
    imageAlt: "Tampilan website Our Gallery",
    demo: "https://oour-galleryxe.vercel.app",
    stack: ["HTML", "CSS", "JavaScript"],
  },
];

const skillGroups = [
  { title: "Technical Skills", items: ["HTML", "CSS", "JavaScript", "Python"] },
  {
    title: "Tools & Technology",
    items: ["Visual Studio Code", "Git & GitHub", "Vercel", "Figma"],
  },
  {
    title: "Beyond Code",
    items: [
      "Pemecahan Masalah",
      "Berpikir Kreatif",
      "Belajar Mandiri",
      "Adaptasi Teknologi",
      "Ketelitian",
      "Manajemen Waktu",
    ],
  },
];

const experiences = [
  {
    period: "2026 — SEKARANG",
    role: "Personal Web Developer",
    place: "Proyek Pribadi",
    description:
      "Mengembangkan proyek website pribadi menggunakan HTML, CSS, dan JavaScript, dengan fokus pada struktur halaman, antarmuka, dan fitur website.",
  },
  {
    period: "2026 — SEKARANG",
    role: "Web Development Learner",
    place: "Pembelajaran Mandiri",
    description:
      "Mempelajari teknologi web dan menerapkan pengetahuan melalui latihan serta berbagai proyek digital.",
  },
];

function Icon({ name, size = 18, strokeWidth = 1.7, className = "" }) {
  const paths = {
    arrowUpRight: <><path d="M7 17 17 7" /><path d="M7 7h10v10" /></>,
    arrowRight: <><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></>,
    music: <><path d="M9 18V5l12-2v13" /><circle cx="6" cy="18" r="3" /><circle cx="18" cy="16" r="3" /></>,
    close: <><path d="m18 6-12 12M6 6l12 12" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></>,
    instagram: <><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><path d="M17.5 6.5h.01" /></>,
    message: <><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z" /></>,
    pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    code: <><path d="m8 17-5-5 5-5M16 7l5 5-5 5M14 4l-4 16" /></>,
    external: <><path d="M14 3h7v7M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></>,
    check: <><path d="m5 12 4 4L19 6" /></>,
    upload: <><path d="M12 16V4m-5 5 5-5 5 5" /><path d="M20 16.5v2A1.5 1.5 0 0 1 18.5 20h-13A1.5 1.5 0 0 1 4 18.5v-2" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    school: <><path d="m3 9 9-5 9 5-9 5-9-5Z" /><path d="M7 11v5c3 2.5 7 2.5 10 0v-5M21 9v6" /></>,
    briefcase: <><rect x="3" y="7" width="18" height="14" rx="2" /><path d="M8 7V4h8v3M3 12h18M10 12v2h4v-2" /></>,
    "user-round": <><circle cx="12" cy="8" r="4" /><path d="M5 21a7 7 0 0 1 14 0" /></>,
    wallet: <><rect x="3" y="5" width="18" height="15" rx="2" /><path d="M3 9h18M16 14h2" /></>,
    "credit-card": <><rect x="2.5" y="5" width="19" height="14" rx="2" /><path d="M2.5 10h19M6 15h3" /></>,
    images: <><rect x="3" y="4" width="14" height="16" rx="2" /><path d="m5 16 4-4 3 3 2-2 3 3M15 7h5a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1h-7" /></>,
    monitor: <><rect x="3" y="3" width="18" height="13" rx="2" /><path d="M8 21h8M12 16v5" /></>,
  };
  const iconSize = typeof size === "number" ? size : ({ xs: 14, sm: 16, md: 18, lg: 20, xl: 24, "2xl": 30, "3xl": 36 }[size] || 18);
  return (
    <svg
      className={className}
      width={iconSize}
      height={iconSize}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] || paths.arrowUpRight}
    </svg>
  );
}

function SectionHeading({ number, eyebrow, title, description }) {
  return (
    <div className="section-heading reveal">
      <p className="eyebrow"><span>{number}</span>{eyebrow}</p>
      <h2>{title}</h2>
      {description ? <p className="section-description">{description}</p> : null}
    </div>
  );
}

function SpotifyPanel({ open, onClose }) {
  if (!open) return null;
  return (
    <div className="spotify-panel" role="dialog" aria-label="Spotify playlist">
      <div className="spotify-panel-head">
        <div>
          <p className="eyebrow"><span>SPOTIFY</span></p>
          <h2>Playlist</h2>
        </div>
        <button type="button" className="icon-button" onClick={onClose} aria-label="Tutup pemutar Spotify">
          <Icon name="close" />
        </button>
      </div>
      <iframe
        title="Spotify Playlist Raditya Saputra"
        data-testid="embed-iframe"
        src={SPOTIFY_EMBED_URL}
        width="100%"
        height="352"
        style={{ borderRadius: "12px", border: 0 }}
        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
        loading="lazy"
        allowFullScreen
      />
      <a className="spotify-direct-link" href="https://open.spotify.com/playlist/6IVSqu5z6fwknHLj0JcnNE" target="_blank" rel="noreferrer">
        Buka playlist di Spotify <Icon name="arrowUpRight" size={15} />
      </a>
    </div>
  );
}


const fallingLeafSettings = [
  { src: "/images/maple-leaves/leaf-05.png", left: "5%", delay: "-7s", duration: "24s", size: "29px", drift: "74px", midDrift: "24px", rotate: "520deg" },
  { src: "/images/maple-leaves/leaf-02.png", left: "14%", delay: "-18s", duration: "29s", size: "24px", drift: "-55px", midDrift: "-20px", rotate: "640deg" },
  { src: "/images/maple-leaves/leaf-03.png", left: "24%", delay: "-3s", duration: "26s", size: "31px", drift: "48px", midDrift: "18px", rotate: "470deg" },
  { src: "/images/maple-leaves/leaf-01.png", left: "37%", delay: "-14s", duration: "32s", size: "25px", drift: "-62px", midDrift: "-28px", rotate: "700deg" },
  { src: "/images/maple-leaves/leaf-06.png", left: "49%", delay: "-10s", duration: "27s", size: "27px", drift: "68px", midDrift: "32px", rotate: "560deg" },
  { src: "/images/maple-leaves/leaf-04.png", left: "62%", delay: "-1s", duration: "30s", size: "26px", drift: "-46px", midDrift: "-17px", rotate: "620deg" },
  { src: "/images/maple-leaves/leaf-07.png", left: "73%", delay: "-22s", duration: "25s", size: "31px", drift: "58px", midDrift: "22px", rotate: "760deg" },
  { src: "/images/maple-leaves/leaf-03.png", left: "85%", delay: "-11s", duration: "33s", size: "23px", drift: "-64px", midDrift: "26px", rotate: "690deg" },
  { src: "/images/maple-leaves/leaf-01.png", left: "94%", delay: "-25s", duration: "28s", size: "28px", drift: "42px", midDrift: "-18px", rotate: "590deg" },
  { src: "/images/maple-leaves/leaf-06.png", left: "31%", delay: "-20s", duration: "34s", size: "22px", drift: "52px", midDrift: "-25px", rotate: "610deg" },
  { src: "/images/maple-leaves/leaf-04.png", left: "57%", delay: "-16s", duration: "31s", size: "24px", drift: "-45px", midDrift: "24px", rotate: "480deg" },
  { src: "/images/maple-leaves/leaf-02.png", left: "79%", delay: "-6s", duration: "27s", size: "27px", drift: "63px", midDrift: "-18px", rotate: "720deg" },
];

function MapleAtmosphere() {
  return (
    <>
      <div className="maple-tree-layer" aria-hidden="true">
        <img className="maple-tree-art" src="/images/maple-tree.png" alt="" draggable="false" />
      </div>
      <div className="falling-leaves-layer" aria-hidden="true">
        {fallingLeafSettings.map((leaf, index) => (
          <img
            key={index}
            className={`falling-maple-leaf falling-maple-leaf-${index + 1}`}
            src={leaf.src}
            alt=""
            draggable="false"
            style={{
              left: leaf.left,
              animationDelay: leaf.delay,
              animationDuration: leaf.duration,
              width: leaf.size,
              height: "auto",
              "--leaf-drift": leaf.drift,
              "--leaf-mid-drift": leaf.midDrift,
              "--leaf-rotation": leaf.rotate,
            }}
          />
        ))}
      </div>
    </>
  );
}

function CommentForm({ onSubmitted }) {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState("");
  const [sending, setSending] = useState(false);
  const [notice, setNotice] = useState(null);
  const [cooldown, setCooldown] = useState(0);
  const [configMissing, setConfigMissing] = useState(false);
  const [website, setWebsite] = useState("");
  const photoInput = useRef(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const response = await fetch("/api/comments", { cache: "no-store" });
        const result = await response.json();
        if (response.status === 503 || result.configured === false) {
          setConfigMissing(true);
          return;
        }
        if (typeof result.retryAfterSeconds === "number") setCooldown(result.retryAfterSeconds);
      } catch {
        setNotice({ type: "error", text: "Status komentar belum dapat diperiksa." });
      }
    };
    fetchStatus();
  }, []);

  useEffect(() => {
    if (cooldown <= 0) return undefined;
    const timer = window.setTimeout(() => setCooldown((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearTimeout(timer);
  }, [cooldown]);

  useEffect(() => () => {
    if (photoPreview) URL.revokeObjectURL(photoPreview);
  }, [photoPreview]);

  function handlePhotoChange(event) {
    const file = event.target.files?.[0];
    setNotice(null);
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setNotice({ type: "error", text: "Foto harus berformat JPG, PNG, atau WebP." });
      event.target.value = "";
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setNotice({ type: "error", text: "Ukuran foto maksimal 2 MB." });
      event.target.value = "";
      return;
    }
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    setPhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setNotice(null);
    if (configMissing) {
      setNotice({ type: "error", text: "Fitur komentar belum dikonfigurasi. Hubungkan Supabase terlebih dahulu." });
      return;
    }
    if (cooldown > 0) return;
    if (!name.trim() || !message.trim()) {
      setNotice({ type: "error", text: "Nama dan komentar wajib diisi." });
      return;
    }
    if (message.trim().length > 1000) {
      setNotice({ type: "error", text: "Komentar maksimal 1.000 karakter." });
      return;
    }
    setSending(true);
    try {
      let photoDataUrl = null;
      if (photo) {
        photoDataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ""));
          reader.onerror = () => reject(new Error("Foto profil tidak dapat dibaca."));
          reader.readAsDataURL(photo);
        });
      }
      const response = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), message: message.trim(), website, photo: photoDataUrl }),
      });
      const result = await response.json();
      if (response.status === 429) {
        setCooldown(result.retryAfterSeconds || 140);
        setNotice({ type: "error", text: result.error || "Tunggu sebelum mengirim komentar lagi." });
        return;
      }
      if (!response.ok) throw new Error(result.error || "Komentar belum dapat dikirim.");
      setCooldown(140);
      setName("");
      setMessage("");
      setWebsite("");
      setPhoto(null);
      setPhotoPreview((old) => {
        if (old) URL.revokeObjectURL(old);
        return "";
      });
      if (photoInput.current) photoInput.current.value = "";
      setNotice({ type: "success", text: "Komentar diterima dan menunggu moderasi sebelum ditampilkan." });
      onSubmitted?.();
    } catch (error) {
      setNotice({ type: "error", text: error.message || "Terjadi kesalahan saat mengirim komentar." });
    } finally {
      setSending(false);
    }
  }

  const cooldownLabel = `${String(Math.floor(cooldown / 60)).padStart(2, "0")}:${String(cooldown % 60).padStart(2, "0")}`;

  return (
    <form className="comment-form" onSubmit={handleSubmit}>
      <div className="form-title-row">
        <div>
          <p className="eyebrow"><span>YOUR MESSAGE</span></p>
          <h3>Leave a comment</h3>
        </div>
        <span className="form-index">140 SEC COOLDOWN</span>
      </div>
      {configMissing ? (
        <div className="notice notice-warning" role="status">
          Fitur komentar sudah disiapkan, tetapi belum aktif karena konfigurasi Supabase belum diisi. Petunjuk tersedia di file README.
        </div>
      ) : null}
      <div className="field-group">
        <label htmlFor="comment-name">Nama</label>
        <input id="comment-name" value={name} onChange={(event) => setName(event.target.value)} maxLength={60} placeholder="Nama kamu" autoComplete="name" required disabled={sending} />
      </div>
      <div className="field-group">
        <span className="field-label">Foto profil <span>(opsional)</span></span>
        <div className="photo-upload-row">
          <div className="avatar-preview">
            {photoPreview ? <img src={photoPreview} alt="Preview foto profil" /> : <span>{name.trim().charAt(0).toUpperCase() || "R"}</span>}
          </div>
          <div className="upload-meta">
            <button className="text-button" type="button" onClick={() => photoInput.current?.click()} disabled={sending}>
              <Icon name="upload" size={15} /> {photo ? "Ganti foto" : "Pilih foto"}
            </button>
            <p>JPG, PNG, atau WebP · maks. 2 MB</p>
            {photo ? <button className="remove-photo" type="button" onClick={() => { setPhoto(null); setPhotoPreview((old) => { if (old) URL.revokeObjectURL(old); return ""; }); if (photoInput.current) photoInput.current.value = ""; }}>Hapus foto</button> : null}
          </div>
          <input ref={photoInput} className="visually-hidden" type="file" accept="image/jpeg,image/png,image/webp" onChange={handlePhotoChange} aria-label="Pilih foto profil" />
        </div>
      </div>
      <div className="field-group">
        <div className="label-counter"><label htmlFor="comment-message">Komentar</label><span>{message.length}/1000</span></div>
        <textarea id="comment-message" value={message} onChange={(event) => setMessage(event.target.value)} maxLength={1000} rows={4} placeholder="Tulis pesan kamu..." required disabled={sending} />
      </div>
      <div className="honeypot" aria-hidden="true">
        <label htmlFor="comment-website">Website</label>
        <input id="comment-website" tabIndex={-1} autoComplete="off" value={website} onChange={(event) => setWebsite(event.target.value)} />
      </div>
      {notice ? <div className={`notice ${notice.type === "success" ? "notice-success" : "notice-error"}`} role="status">{notice.text}</div> : null}
      <button className="button button-primary submit-button" type="submit" disabled={sending || cooldown > 0 || configMissing}>
        {sending ? "Mengirim..." : cooldown > 0 ? `Kirim lagi dalam ${cooldownLabel}` : "Kirim komentar"}
        {!sending && cooldown === 0 ? <Icon name="arrowUpRight" size={16} /> : null}
      </button>
      <p className="form-footnote"><Icon name="clock" size={14} /> Komentar ditinjau sebelum dipublikasikan. Jeda pengiriman 140 detik.</p>
    </form>
  );
}

function CommentsList({ refreshKey }) {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadComments = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/comments", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Komentar belum dapat dimuat.");
      setComments(Array.isArray(result.comments) ? result.comments : []);
      setError("");
    } catch (loadError) {
      setError(loadError.message || "Komentar belum dapat dimuat.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadComments(); }, [loadComments, refreshKey]);

  return (
    <div className="comments-list">
      <div className="comments-list-heading">
        <div>
          <p className="eyebrow"><span>COMMUNITY</span></p>
          <h3>Comments <span className="count-pill">{comments.length}</span></h3>
        </div>
        <button type="button" className="refresh-button" onClick={loadComments} disabled={loading} aria-label="Muat ulang komentar">{loading ? "Memuat..." : "Refresh"}</button>
      </div>
      {loading ? <p className="list-state">Memuat komentar...</p> : null}
      {!loading && error ? <p className="list-state">{error}</p> : null}
      {!loading && !error && comments.length === 0 ? <div className="empty-comments"><span className="empty-line"/><p>Belum ada komentar yang dipublikasikan.</p><span>Jadilah yang pertama berbagi pesan.</span></div> : null}
      {!loading && !error && comments.length > 0 ? (
        <div className="comment-items">
          {comments.map((comment) => (
            <article className="comment-item" key={comment.id}>
              <div className="comment-avatar">{comment.avatar_url ? <img src={comment.avatar_url} alt={`Foto profil ${comment.name}`} /> : <span>{comment.name?.trim()?.charAt(0)?.toUpperCase() || "?"}</span>}</div>
              <div className="comment-body">
                <div className="comment-meta"><h4>{comment.name}</h4><time dateTime={comment.created_at}>{new Date(comment.created_at).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" })}</time></div>
                <p>{comment.message}</p>
              </div>
            </article>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [spotifyOpen, setSpotifyOpen] = useState(false);
  const [alternatePhoto, setAlternatePhoto] = useState(false);
  const [spotlightActive, setSpotlightActive] = useState(false);
  const [commentRefreshKey, setCommentRefreshKey] = useState(0);
  const [activeSection, setActiveSection] = useState("about");
  const profileButtonRef = useRef(null);
  const spotlightMotionRef = useRef({ x: 50, y: 50, targetX: 50, targetY: 50, frame: 0 });

  useEffect(() => () => {
    if (spotlightMotionRef.current.frame) cancelAnimationFrame(spotlightMotionRef.current.frame);
  }, []);

  useEffect(() => {
    const elements = document.querySelectorAll(".reveal");
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      elements.forEach((element) => element.classList.add("is-visible"));
      return undefined;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const sections = ["about", "skills", "projects", "experience", "education", "contact"];
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) setActiveSection(entry.target.id);
      });
    }, { rootMargin: "-28% 0px -62% 0px" });
    sections.forEach((id) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    document.body.classList.toggle("menu-open", mobileMenuOpen);
    return () => document.body.classList.remove("menu-open");
  }, [mobileMenuOpen]);

  function handleProfilePointerMove(event) {
    if (event.pointerType !== "mouse") return;
    const rect = event.currentTarget.getBoundingClientRect();
    const motion = spotlightMotionRef.current;
    const targetX = Math.max(0, Math.min(100, ((event.clientX - rect.left) / rect.width) * 100));
    const targetY = Math.max(0, Math.min(100, ((event.clientY - rect.top) / rect.height) * 100));
    motion.targetX = targetX;
    motion.targetY = targetY;
    if (!spotlightActive) {
      // Place the spotlight at the entry point immediately; smooth only subsequent movement.
      motion.x = targetX;
      motion.y = targetY;
      event.currentTarget.style.setProperty("--spotlight-x", `${targetX}%`);
      event.currentTarget.style.setProperty("--spotlight-y", `${targetY}%`);
      setSpotlightActive(true);
    }

    if (motion.frame) return;
    const animate = () => {
      const state = spotlightMotionRef.current;
      const ease = 0.28;
      state.x += (state.targetX - state.x) * ease;
      state.y += (state.targetY - state.y) * ease;
      const element = profileButtonRef.current;
      if (element) {
        element.style.setProperty("--spotlight-x", `${state.x.toFixed(3)}%`);
        element.style.setProperty("--spotlight-y", `${state.y.toFixed(3)}%`);
      }
      const remaining = Math.abs(state.targetX - state.x) + Math.abs(state.targetY - state.y);
      if (remaining > 0.08) {
        state.frame = requestAnimationFrame(animate);
      } else {
        state.x = state.targetX;
        state.y = state.targetY;
        if (element) {
          element.style.setProperty("--spotlight-x", `${state.x.toFixed(3)}%`);
          element.style.setProperty("--spotlight-y", `${state.y.toFixed(3)}%`);
        }
        state.frame = 0;
      }
    };
    motion.frame = requestAnimationFrame(animate);
  }

  function handleProfilePointerLeave(event) {
    if (event.pointerType === "mouse") setSpotlightActive(false);
  }

  function handleProfileClick(event) {
    const isTouch = typeof window !== "undefined" && window.matchMedia("(hover: none)").matches;
    const isKeyboardActivation = event.detail === 0;
    if (isTouch || isKeyboardActivation) setAlternatePhoto((value) => !value);
  }

  const navItems = [
    { id: "about", label: "About" },
    { id: "skills", label: "Skills" },
    { id: "projects", label: "Projects" },
    { id: "experience", label: "Experience" },
    { id: "education", label: "Education" },
    { id: "contact", label: "Contact" },
  ];

  function handleNavClick(id) {
    setActiveSection(id);
    setMobileMenuOpen(false);
  }

  return (
    <main className="site-main">
      <MapleAtmosphere />
      <header className="site-header">
        <div className="nav-shell">
          <a href="#home" className="brand" aria-label="Radit, kembali ke atas">RADIT<span>.</span></a>
          <nav className={`main-nav ${mobileMenuOpen ? "nav-open" : ""}`} aria-label="Navigasi utama">
            {navItems.map((item) => (
              <a key={item.id} className={activeSection === item.id ? "nav-link active" : "nav-link"} href={`#${item.id}`} onClick={() => handleNavClick(item.id)}>{item.label}</a>
            ))}
          </nav>
          <div className="nav-actions">
            <button type="button" className={`music-trigger ${spotifyOpen ? "is-open" : ""}`} onClick={() => setSpotifyOpen((value) => !value)} aria-expanded={spotifyOpen} aria-controls="spotify-player" aria-label={spotifyOpen ? "Tutup Spotify playlist" : "Buka Spotify playlist"}>
              <Icon name="music" size={17}/><span>Playlist</span>
            </button>
            <button type="button" className="mobile-menu-button" onClick={() => setMobileMenuOpen((value) => !value)} aria-expanded={mobileMenuOpen} aria-label={mobileMenuOpen ? "Tutup navigasi" : "Buka navigasi"}>
              <Icon name={mobileMenuOpen ? "close" : "menu"} size={21}/>
            </button>
          </div>
        </div>
        <div id="spotify-player" className={`spotify-anchor ${spotifyOpen ? "spotify-anchor-open" : ""}`}>
          <SpotifyPanel open={spotifyOpen} onClose={() => setSpotifyOpen(false)} />
        </div>
      </header>

      <section className="hero-section page-shell" id="home">
        <div className="hero-copy">
          <p className="eyebrow hero-eyebrow"><span className="availability-dot"/> PELAJAR PPLG <span className="eyebrow-divider">/</span> WEB DEVELOPER</p>
          <h1>Mengubah Inspirasi <span>Menjadi Kreasi</span></h1>
          <p className="hero-description">Saya membangun solusi digital yang fungsional, kreatif, dan memberikan manfaat bagi pengguna.</p>
          <div className="hero-actions">
            <a href="#projects" className="button button-primary">Lihat Proyek <Icon name="arrowUpRight" size={16}/></a>
            <a href="#contact" className="button button-secondary">Hubungi Saya <Icon name="arrowRight" size={16}/></a>
          </div>
          <div className="hero-meta">
            <span><Icon name="pin" size={14}/> Pandaan, Jawa Timur</span>
            <span className="meta-divider"/>
            <span>Terbuka untuk kolaborasi</span>
          </div>
        </div>
        <div className="hero-portrait-wrap reveal">
          <button
            ref={profileButtonRef}
            type="button"
            className={`hero-portrait ${spotlightActive ? "spotlight-active" : ""} ${alternatePhoto ? "touch-alternate" : ""}`}
            onPointerMove={handleProfilePointerMove}
            onPointerLeave={handleProfilePointerLeave}
            onClick={handleProfileClick}
            aria-label="Foto profil interaktif. Arahkan kursor untuk menyorot foto alternatif; aktifkan dengan keyboard atau ketuk untuk mengganti foto."
            aria-pressed={alternatePhoto}
          >
            <img src="/images/profile-main.jpg" alt="Foto profil Raditya Saputra" className="portrait-image portrait-main" draggable="false" fetchPriority="high" />
            <img src="/images/profile-hover.jpg" alt="" className="portrait-image portrait-alternate" draggable="false" />
            <span className="portrait-spotlight-ring" aria-hidden="true" />
            <span className="portrait-index">RADIT / 01</span>
          </button>
          <div className="portrait-caption"><span>RADITYA SAPUTRA</span><span>PERSONAL PORTFOLIO · 2026</span></div>
        </div>
        <a href="#about" className="scroll-cue" aria-label="Gulir ke bagian About"><span/> SCROLL TO EXPLORE</a>
      </section>

      <section className="content-section about-section page-shell" id="about">
        <SectionHeading number="01" eyebrow="ABOUT ME" title="Mengenal Saya Lebih Dekat" />
        <div className="about-grid">
          <p className="about-lead reveal">Saya Raditya Saputra, pelajar yang tertarik pada <span>Web Development</span> dan cara teknologi membantu menyelesaikan masalah nyata.</p>
          <div className="about-detail reveal">
            <p>Saya senang mempelajari teknologi baru, mengembangkan ide kreatif, dan mengerjakan proyek secara terstruktur. Saya terus mengasah kemampuan melalui pembelajaran mandiri dan praktik langsung.</p>
            <div className="facts-grid">
              <div className="fact"><span>LOCATION</span><strong>Pandaan, Pasuruan</strong></div>
              <div className="fact"><span>STATUS</span><strong>Pelajar PPLG</strong></div>
              <div className="fact"><span>FOCUS</span><strong>Web Development & UI/UX</strong></div>
              <div className="fact"><span>EDUCATION</span><strong>SMK Muhammadiyah 1 Pandaan</strong></div>
            </div>
          </div>
        </div>
      </section>

      <section className="content-section skills-section page-shell" id="skills">
        <SectionHeading number="02" eyebrow="SKILLS & TOOLS" title="Keahlian dan Teknologi" description="Teknologi yang saya gunakan dan kemampuan yang terus saya kembangkan." />
        <div className="skills-grid">
          {skillGroups.map((group, index) => (
            <article className="skill-group reveal" key={group.title}>
              <div className="skill-topline"><span>0{index + 1}</span><span>{group.items.length.toString().padStart(2, "0")} ITEMS</span></div>
              <h3>{group.title}</h3>
              <div className="skill-list">{group.items.map((item) => <span className="skill-chip" key={item}>{item}</span>)}</div>
            </article>
          ))}
        </div>
      </section>

      <section className="content-section projects-section page-shell" id="projects">
        <div className="section-heading-row">
          <SectionHeading number="03" eyebrow="SELECTED WORKS" title="Proyek Pilihan" description="Beberapa karya yang saya kembangkan untuk belajar dan membangun pengalaman." />
          <span className="section-side-note">PERSONAL PROJECTS / 2026</span>
        </div>
        <div className="projects-grid">
          {projects.map((project) => (
            <article className="project-card reveal" key={project.number}>
              <a className="project-image-link" href={project.demo} target="_blank" rel="noreferrer" aria-label={`Buka demo ${project.title}`}>
                <div className="project-image-wrap"><img src={project.image} alt={project.imageAlt} className="project-image" loading="lazy" /></div>
                <span className="project-open"><Icon name="arrowUpRight" size={18}/></span>
              </a>
              <div className="project-content">
                <div className="project-meta"><span>{project.category}</span><span>{project.number}</span></div>
                <h3>{project.title}</h3>
                <p className="project-subtitle">{project.subtitle}</p>
                <p className="project-description">{project.description}</p>
                <div className="project-stack">{project.stack.map((tech) => <span key={tech}>{tech}</span>)}</div>
                <a className="project-demo" href={project.demo} target="_blank" rel="noreferrer">Live Demo <Icon name="arrowUpRight" size={15}/></a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="content-section experience-section page-shell" id="experience">
        <SectionHeading number="04" eyebrow="EXPERIENCE" title="Proses yang Terus Berjalan" description="Pengalaman membangun proyek dan belajar secara mandiri." />
        <div className="timeline">
          {experiences.map((experience, index) => (
            <article className="timeline-item reveal" key={experience.role}>
              <div className="timeline-marker"><span/></div>
              <div className="timeline-period">{experience.period}</div>
              <div className="timeline-content"><p className="timeline-place">{experience.place}</p><h3>{experience.role}</h3><p>{experience.description}</p></div>
              <span className="timeline-number">0{index + 1}</span>
            </article>
          ))}
        </div>
      </section>

      <section className="content-section education-section page-shell" id="education">
        <SectionHeading number="05" eyebrow="EDUCATION" title="Pendidikan" />
        <article className="education-card reveal">
          <div className="school-logo-wrap"><img src="/images/school-logo.png" alt="Logo SMK Muhammadiyah 1 Pandaan" width="553" height="553" loading="lazy" /></div>
          <div className="education-info"><p className="eyebrow"><span>2026 — 2029</span></p><h3>SMK Muhammadiyah 1 Pandaan</h3><p>Pengembangan Perangkat Lunak dan Gim (PPLG)</p></div>
          <span className="education-tag">STUDENT</span>
        </article>
      </section>

      <section className="content-section contact-section page-shell" id="contact">
        <SectionHeading number="06" eyebrow="CONTACT & COMMUNITY" title="Mari Berkolaborasi" description="Tertarik berdiskusi seputar website, teknologi, atau ide proyek digital? Saya terbuka untuk bertukar ide dan belajar bersama." />
        <div className="contact-grid">
          <div className="contact-info reveal">
            <p className="contact-intro">Punya ide yang ingin dibicarakan? Kirim pesan atau temukan saya melalui kanal berikut.</p>
            <a className="contact-link" href="mailto:raditcyper1@gmail.com"><span className="contact-icon"><Icon name="mail" size={18}/></span><span className="contact-link-copy"><small>EMAIL</small><strong>raditcyper1@gmail.com</strong></span><Icon name="arrowUpRight" size={17} className="contact-arrow"/></a>
            <a className="contact-link" href="https://www.instagram.com/xn0ne_404?cplk=c3lyMWVtdjY5eGdr" target="_blank" rel="noreferrer"><span className="contact-icon"><Icon name="instagram" size={18}/></span><span className="contact-link-copy"><small>INSTAGRAM</small><strong>@xn0ne_404</strong></span><Icon name="arrowUpRight" size={17} className="contact-arrow"/></a>
            <a className="contact-link" href="https://www.tiktok.com/@xenone404?_r=1&_t=ZS-9A557I1qhvT" target="_blank" rel="noreferrer"><span className="contact-icon"><Icon name="message" size={18}/></span><span className="contact-link-copy"><small>TIKTOK</small><strong>@xenone404</strong></span><Icon name="arrowUpRight" size={17} className="contact-arrow"/></a>
            <a className="contact-link" href="https://t.me/ditzXT17" target="_blank" rel="noreferrer"><span className="contact-icon"><Icon name="message" size={18}/></span><span className="contact-link-copy"><small>TELEGRAM</small><strong>@ditzXT17</strong></span><Icon name="arrowUpRight" size={17} className="contact-arrow"/></a>
            <div className="contact-note"><span className="availability-dot"/> Terbuka untuk bertukar ide dan kolaborasi</div>
          </div>
          <CommentForm onSubmitted={() => setCommentRefreshKey((value) => value + 1)} />
        </div>
        <CommentsList refreshKey={commentRefreshKey} />
      </section>

      <footer className="site-footer page-shell">
        <a href="#home" className="brand">RADIT<span>.</span></a>
        <p>Designed and developed with creativity.</p>
        <span>© 2026 Radit. All rights reserved.</span>
      </footer>
    </main>
  );
}
