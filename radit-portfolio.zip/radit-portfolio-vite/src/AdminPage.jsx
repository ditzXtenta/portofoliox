import { useState } from 'react';

export default function AdminPage() {
  const [token, setToken] = useState('');
  const [comments, setComments] = useState([]);
  const [status, setStatus] = useState('Masukkan token admin untuk memuat komentar yang menunggu moderasi.');
  const [busyId, setBusyId] = useState('');
  const [loading, setLoading] = useState(false);

  const loadComments = async (event) => {
    event?.preventDefault();
    if (!token.trim()) { setStatus('Token admin wajib diisi.'); return; }
    setLoading(true); setStatus('Memuat antrean komentar...');
    try {
      const response = await fetch('/api/admin/comments', { headers: { Authorization: `Bearer ${token.trim()}` } });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Antrean tidak dapat dimuat.');
      setComments(Array.isArray(data.comments) ? data.comments : []);
      setStatus(`${data.comments?.length || 0} komentar menunggu moderasi.`);
    } catch (error) { setStatus(error.message || 'Terjadi kesalahan.'); }
    finally { setLoading(false); }
  };

  const moderate = async (id, nextStatus) => {
    setBusyId(id); setStatus('Memperbarui status komentar...');
    try {
      const response = await fetch('/api/admin/comments', { method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token.trim()}` }, body: JSON.stringify({ id, status: nextStatus }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Status komentar gagal diperbarui.');
      setComments((current) => current.filter((comment) => comment.id !== id));
      setStatus(nextStatus === 'approved' ? 'Komentar disetujui dan akan tampil di website.' : 'Komentar ditolak.');
    } catch (error) { setStatus(error.message || 'Terjadi kesalahan.'); }
    finally { setBusyId(''); }
  };

  return (
    <main className="admin-page">
      <div className="admin-wrap">
        <header className="admin-header">
          <div><p className="eyebrow">RADIT / PRIVATE AREA</p><h1>Moderasi Komentar<span style={{ color: 'var(--maple-light)' }}>.</span></h1></div>
          <a className="admin-back" href="/"><span aria-hidden="true">←</span> Kembali ke website</a>
        </header>
        <section className="admin-card">
          <form className="admin-form" onSubmit={loadComments}>
            <input type="password" autoComplete="current-password" value={token} onChange={(event) => setToken(event.target.value)} placeholder="Token admin" aria-label="Token admin" required />
            <button className="button button-primary" type="submit" disabled={loading}>{loading ? 'Memuat...' : 'Muat Komentar'}</button>
          </form>
          <p className="admin-status" role="status">{status}</p>
          <div className="admin-queue">
            {comments.map((comment) => <article className="admin-comment" key={comment.id}>
              <div>{comment.avatar_url ? <img src={comment.avatar_url} alt="" /> : <div className="comment-avatar">{comment.name?.[0]?.toUpperCase() || '?'}</div>}</div>
              <div><h3>{comment.name}</h3><time>{new Date(comment.created_at).toLocaleString('id-ID')}</time><p>{comment.message}</p><div className="admin-actions"><button className="approve" disabled={busyId === comment.id} onClick={() => moderate(comment.id, 'approved')}>Setujui</button><button className="reject" disabled={busyId === comment.id} onClick={() => moderate(comment.id, 'rejected')}>Tolak</button></div></div>
            </article>)}
          </div>
        </section>
      </div>
    </main>
  );
}
