import { useEffect, useMemo, useRef, useState } from 'react';
import AdminPage from './AdminPage.jsx';

const projects = [
  {
    id: 'beruang',
    name: 'Beruang',
    fullName: 'Beruang — Financial Planner',
    category: 'WEB APP',
    description: 'Aplikasi pengelolaan keuangan yang membantu pengguna mencatat pemasukan, pengeluaran, dan memantau kondisi keuangan secara praktis.',
    role: 'Web Developer',
    stack: ['HTML', 'CSS', 'JavaScript'],
    image: '/images/beruang.webp',
    alt: 'Tampilan dashboard aplikasi Beruang Financial Planner',
    url: 'https://beruang-livid.vercel.app/',
    overview: 'Beruang dirancang sebagai antarmuka pengelolaan keuangan personal dengan ringkasan kondisi keuangan dalam satu dashboard.',
    features: ['Ringkasan saldo, pemasukan, dan pengeluaran', 'Navigasi transaksi dan budget', 'Area goals dan analitik keuangan'],
  },
  {
    id: 'payment',
    name: 'Payment',
    fullName: 'Payment — Digital Payment Guide',
    category: 'WEB APP',
    description: 'Website pembayaran digital dengan tampilan modern yang memudahkan pengguna memahami informasi pembayaran dan melakukan transaksi secara praktis.',
    role: 'Web Developer',
    stack: ['HTML', 'CSS', 'JavaScript'],
    image: '/images/payment.webp',
    alt: 'Tampilan website Payment dengan pilihan metode pembayaran',
    url: 'https://allpayrdc.vercel.app',
    overview: 'Payment menyajikan pilihan metode pembayaran dalam satu antarmuka yang ringkas dan mudah dipahami.',
    features: ['Pilihan QRIS, DANA, dan GoPay', 'Informasi cara pembayaran', 'Antarmuka berorientasi pada kemudahan navigasi'],
  },
  {
    id: 'our-gallery',
    name: 'Our Gallery',
    fullName: 'Our Gallery — Digital Memories',
    category: 'WEBSITE GALERI',
    description: 'Website galeri digital untuk menampilkan koleksi foto dengan desain yang menarik, rapi, dan responsif di berbagai perangkat.',
    role: 'Web Developer',
    stack: ['HTML', 'CSS', 'JavaScript'],
    image: '/images/our-gallery.webp',
    alt: 'Tampilan website Our Gallery untuk menyimpan dan melihat foto',
    url: 'https://oour-galleryxe.vercel.app',
    overview: 'Our Gallery dibuat sebagai ruang digital untuk menampilkan dan menyimpan momen melalui pengalaman visual yang sederhana.',
    features: ['Tampilan galeri foto', 'Area untuk menambahkan foto', 'Desain visual yang ringan dan responsif'],
  },
];

const fallingLeaves = [
  { src: '/images/maple-leaves/leaf-01.png', left: '4%', delay: '-7s', duration: '28s', width: '26px', drift: '48px', mid: '22px', back: '-12px', rotate: '430deg' },
  { src: '/images/maple-leaves/leaf-02.png', left: '15%', delay: '-18s', duration: '32s', width: '22px', drift: '-38px', mid: '-19px', back: '11px', rotate: '570deg' },
  { src: '/images/maple-leaves/leaf-03.png', left: '29%', delay: '-3s', duration: '29s', width: '25px', drift: '36px', mid: '17px', back: '-9px', rotate: '480deg' },
  { src: '/images/maple-leaves/leaf-04.png', left: '68%', delay: '-13s', duration: '33s', width: '23px', drift: '-45px', mid: '-22px', back: '13px', rotate: '620deg' },
  { src: '/images/maple-leaves/leaf-05.png', left: '82%', delay: '-22s', duration: '30s', width: '27px', drift: '34px', mid: '16px', back: '-11px', rotate: '530deg' },
  { src: '/images/maple-leaves/leaf-06.png', left: '94%', delay: '-10s', duration: '34s', width: '22px', drift: '-28px', mid: '-14px', back: '8px', rotate: '460deg' },
  { src: '/images/maple-leaves/leaf-07.png', left: '54%', delay: '-25s', duration: '36s', width: '24px', drift: '40px', mid: '19px', back: '-13px', rotate: '590deg' },
];

function Icon({ name, size = 18, className = '' }) {
  const shared = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true, className };
  const paths = {
    arrow: <><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></>,
    external: <><path d="M14 3h7v7"/><path d="M10 14 21 3"/><path d="M19 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h6"/></>,
    music: <><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></>,
    close: <><path d="m18 6-12 12M6 6l12 12"/></>,
    back: <><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></>,
    folder: <><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/><path d="M3.5 10h17"/></>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    sparkle: <><path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/></>,
  };
  return <svg {...shared}>{paths[name] || paths.sparkle}</svg>;
}

function BrandIcon({ name, size = 28 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', 'aria-hidden': true, focusable: 'false' };
  if (name === 'HTML') return <svg {...common}><path fill="#E34F26" d="M2 1h20l-1.8 20.2L12 23.5 3.8 21.2z"/><path fill="#EF652A" d="M12 3v18.1l6.5-1.8L20 3z"/><path fill="#fff" d="M5.5 5.4h13l-.2 2.5H8.3l.2 2.4h9.6l-.8 7.3-5.3 1.5-5.2-1.5-.3-3.6h2.6l.2 1.7 2.7.8 2.8-.8.3-2.9H6.2z"/></svg>;
  if (name === 'CSS') return <svg {...common}><path fill="#1572B6" d="M2 1h20l-1.8 20.2L12 23.5 3.8 21.2z"/><path fill="#33A9DC" d="M12 3v18.1l6.5-1.8L20 3z"/><path fill="#fff" d="M5.5 5.4h13l-.2 2.5H8.3l.2 2.4h9.6l-.8 7.3-5.3 1.5-5.2-1.5-.3-3.6h2.6l.2 1.7 2.7.8 2.8-.8.3-2.9H6.2z"/></svg>;
  if (name === 'JavaScript') return <svg {...common}><rect x="1" y="1" width="22" height="22" rx="2" fill="#F7DF1E"/><path fill="#171717" d="M12.4 17.1c.45.74 1.03 1.28 2.06 1.28.87 0 1.42-.43 1.42-1.02 0-.71-.56-.96-1.52-1.38l-.52-.22c-1.5-.64-2.5-1.44-2.5-3.13 0-1.56 1.19-2.75 3.05-2.75 1.32 0 2.27.46 2.95 1.68l-1.62 1.04c-.36-.64-.75-.89-1.33-.89-.61 0-1 .39-1 .89 0 .62.39.87 1.29 1.26l.52.22c1.77.76 2.77 1.53 2.77 3.27 0 1.87-1.47 2.9-3.45 2.9-1.93 0-3.18-.92-3.79-2.12zm-7.35.18 1.83-1.11c.35.62.67 1.15 1.45 1.15.74 0 1.2-.29 1.2-1.42v-7h2.25v7.03c0 2.33-1.37 3.39-3.36 3.39-1.8 0-2.84-.93-3.37-2.04"/></svg>;
  if (name === 'Python') return <svg {...common}><path fill="#3776AB" d="M11.9 1.2c-5.2 0-4.9 2.25-4.9 2.25v2.33h5v.7H5.05S1.2 6.04 1.2 11.3s3.35 5.08 3.35 5.08h2v-2.45s-.11-2.92 2.86-2.92h4.92s2.76.05 2.76-2.67V4.15s.42-2.95-5.19-2.95zM9.15 3.03a.96.96 0 1 1 0 1.92.96.96 0 0 1 0-1.92z"/><path fill="#FFD343" d="M12.1 22.8c5.2 0 4.9-2.25 4.9-2.25v-2.33h-5v-.7h6.95s3.85.44 3.85-4.82-3.35-5.08-3.35-5.08h-2v2.45s.11 2.92-2.86 2.92H9.67s-2.76-.05-2.76 2.67v4.19s-.42 2.95 5.19 2.95zm2.75-1.83a.96.96 0 1 1 0-1.92.96.96 0 0 1 0 1.92z"/></svg>;
  if (name === 'React') return <svg {...common} viewBox="0 0 32 32"><g fill="none" stroke="#61DAFB" strokeWidth="1.8"><ellipse cx="16" cy="16" rx="13" ry="5.1"/><ellipse cx="16" cy="16" rx="13" ry="5.1" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="13" ry="5.1" transform="rotate(120 16 16)"/></g><circle cx="16" cy="16" r="2.4" fill="#61DAFB"/></svg>;
  if (name === 'Vite') return <svg {...common} viewBox="0 0 24 24"><path fill="#646CFF" d="M1.2 4.2 11.4 22a.7.7 0 0 0 1.2 0L22.8 4.2a.7.7 0 0 0-.75-1.02L12 5 2 3.18a.7.7 0 0 0-.8 1.02z"/><path fill="#FFD62E" d="m15.1 1.4-7.2 12a.45.45 0 0 0 .51.67l3.18-.75-.25 5.05a.42.42 0 0 0 .78.24l7.1-12.5a.45.45 0 0 0-.52-.65l-3.27.86.4-4.65a.42.42 0 0 0-.73-.27z"/></svg>;
  if (name === 'email') return <svg {...common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg>;
  if (name === 'instagram') return <svg {...common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.6" cy="6.6" r=".9" fill="currentColor" stroke="none"/></svg>;
  if (name === 'tiktok') return <svg {...common} viewBox="0 0 24 24"><path fill="currentColor" d="M15.6 2h-3.3v13.1a3.2 3.2 0 1 1-2.8-3.17V8.6a6.6 6.6 0 1 0 6.1 6.58V8.55a8.2 8.2 0 0 0 4.6 1.42V6.7c-2.5-.1-4.5-2.1-4.6-4.7z"/></svg>;
  if (name === 'telegram') return <svg {...common} viewBox="0 0 24 24"><path fill="currentColor" d="m21.6 3.3-3.3 17.1c-.25 1.2-.95 1.5-1.93.93l-5.35-3.94-2.58 2.48c-.28.28-.51.51-1.05.51l.38-5.45 9.92-8.96c.43-.38-.1-.59-.67-.21L4.75 13.4l-5.2-1.63c-1.13-.35-1.15-1.13.24-1.67L20.1 2.04c.94-.34 1.76.23 1.5 1.26z" transform="translate(1 1) scale(.92)"/></svg>;
  return null;
}

function MapleAtmosphere() {
  return (
    <div className="atmosphere" aria-hidden="true">
      <img className="maple-tree" src="/images/maple-tree.png" alt="" />
      <div className="falling-leaves">
        {fallingLeaves.map((leaf, index) => (
          <img
            key={`${leaf.src}-${index}`}
            className={`falling-leaf falling-leaf-${index + 1}`}
            src={leaf.src}
            alt=""
            draggable="false"
            style={{
              left: leaf.left,
              width: leaf.width,
              animationDelay: leaf.delay,
              animationDuration: leaf.duration,
              '--leaf-drift': leaf.drift,
              '--leaf-mid-drift': leaf.mid,
              '--leaf-back-drift': leaf.back,
              '--leaf-rotation': leaf.rotate,
            }}
          />
        ))}
      </div>
    </div>
  );
}

function Header({ onPlaylist }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const links = [
    ['About', '#about'], ['Skills', '#skills'], ['Projects', '#projects'],
    ['Experience', '#experience'], ['Education', '#education'], ['Contact', '#contact'],
  ];
  const goTo = (href) => {
    setMenuOpen(false);
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    document.querySelector(href)?.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'start' });
  };
  return (
    <header className="site-header">
      <nav className={`main-nav ${menuOpen ? 'is-open' : ''}`} aria-label="Navigasi utama">
        {links.map(([label, href]) => <a key={href} href={href} onClick={(event) => { event.preventDefault(); goTo(href); }}>{label}</a>)}
      </nav>
      <button className="playlist-trigger" type="button" onClick={onPlaylist}>
        <Icon name="music" size={16} /> <span>Playlist</span>
      </button>
      <button className="mobile-menu-trigger" type="button" aria-label={menuOpen ? 'Tutup menu' : 'Buka menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen((value) => !value)}>
        <Icon name={menuOpen ? 'close' : 'menu'} size={20} />
      </button>
    </header>
  );
}

function SectionHeading({ eyebrow, title, accent, description }) {
  return (
    <div className="section-heading reveal">
      <div className="section-eyebrow"><i />{eyebrow}</div>
      <h2>{title} <span>{accent}</span></h2>
      {description && <p>{description}</p>}
    </div>
  );
}

function Hero() {
  return (
    <section className="hero-section page-width" id="home" aria-label="Perkenalan Raditya Saputra">
      <div className="hero-art reveal">
        <img src="/images/hero-composition.webp" alt="Komposisi portrait Raditya Saputra dengan judul Let's get to know about me, bingkai oranye, dan tiga label perkenalan." fetchPriority="high" />
      </div>
      <div className="hero-bottom reveal">
        <div className="hero-intro">
          <p className="eyebrow">PELAJAR PPLG <span>—</span> WEB DEVELOPER PEMULA</p>
          <p className="hero-tagline">Mengubah Inspirasi <span>Menjadi Kreasi.</span></p>
        </div>
        <div className="hero-actions">
          <a className="button button-primary" href="#projects">Lihat Proyek <Icon name="arrow" size={16} /></a>
          <a className="button button-quiet" href="#contact">Hubungi Saya <Icon name="arrow" size={16} /></a>
        </div>
      </div>
    </section>
  );
}

function About() {
  const facts = [
    ['Lokasi', 'Pandaan, Pasuruan'],
    ['Pendidikan', 'SMK Muhammadiyah 1 Pandaan'],
    ['Status', 'Pelajar PPLG'],
    ['Fokus', 'Web Development & UI/UX'],
  ];
  return (
    <section className="section page-width" id="about">
      <SectionHeading eyebrow="ABOUT ME" title="Mengenal Saya" accent="Lebih Dekat." description="Suka mempelajari teknologi baru, membangun ide, dan mengubahnya menjadi pengalaman digital yang berguna." />
      <div className="about-layout reveal">
        <div className="about-copy">
          <p className="dropcap">Halo, saya Raditya Saputra, seorang pelajar yang tertarik pada bidang Web Development. Saya senang mempelajari teknologi baru, mengembangkan ide kreatif, dan menyelesaikan permasalahan melalui pendekatan yang terstruktur.</p>
          <p>Saya memiliki pengalaman membuat proyek website pribadi, mulai dari aplikasi pengelolaan keuangan hingga website pembayaran dan galeri digital. Saya terus mengembangkan kemampuan melalui pembelajaran mandiri dan praktik langsung.</p>
          <div className="about-signature"><span className="signature-line" /><span>Curiosity into creation.</span></div>
        </div>
        <div className="fact-grid">
          {facts.map(([label, value]) => <div className="fact-item" key={label}><div><span className="fact-label">{label}</span><strong>{value}</strong></div></div>)}
        </div>
      </div>
    </section>
  );
}

function Skills() {
  const groups = [
    { title: 'Technical Skills', skills: ['HTML', 'CSS', 'JavaScript', 'Python', 'React', 'Vite'] },
    { title: 'Tools & Platforms', skills: ['Visual Studio Code', 'Git & GitHub', 'Vercel', 'Figma'] },
    { title: 'Ways of Working', skills: ['Pemecahan Masalah', 'Berpikir Kreatif', 'Belajar Mandiri', 'Adaptasi Teknologi', 'Ketelitian', 'Manajemen Waktu'] },
  ];
  return (
    <section className="section page-width" id="skills">
      <SectionHeading eyebrow="SKILLS & TOOLKIT" title="Keahlian dan" accent="Teknologi." description="Perangkat dan kebiasaan kerja yang saya gunakan untuk terus berkembang." />
      <div className="skills-grid reveal">
        {groups.map((group) => <article className="skill-panel glass-panel" key={group.title}>
          <div className="skill-panel-top"><Icon name="sparkle" size={19} /></div>
          <h3>{group.title}</h3>
          {group.title === 'Technical Skills' ? <div className="technical-skills-grid">{group.skills.map((skill) => <div className="technical-skill" key={skill}><span className={`technical-skill-icon icon-${skill.toLowerCase().replace(/[^a-z]/g, '')}`}><BrandIcon name={skill} size={27} /></span><span>{skill}</span></div>)}</div> : <div className="skill-tags">{group.skills.map((skill) => <span key={skill}>{skill}</span>)}</div>}
        </article>)}
      </div>
    </section>
  );
}

function ProjectFolder({ onOpen }) {
  return (
    <button className="folder-trigger" type="button" onClick={onOpen} aria-label="Buka folder untuk melihat tiga proyek pilihan">
      <div className="folder-scene">
        <div className="folder-glow" />
        <div className="folder-back"><span className="folder-tab" /></div>
        <div className="folder-previews">
          {projects.map((project, index) => <div className={`folder-preview folder-preview-${index + 1}`} key={project.id}>
            <img src={project.image} alt="" loading="lazy" />
            <span>{project.name}</span>
          </div>)}
        </div>
        <div className="folder-front">
          <span className="folder-front-kicker"><Icon name="folder" size={15} /> RADIT'S WORKSPACE</span>
          <span className="folder-front-title">Selected <em>Projects</em></span>
          <span className="folder-front-bottom"><span>3 PROJECTS INSIDE</span><span className="folder-open-icon"><Icon name="arrow" size={18} /></span></span>
        </div>
        <span className="folder-orbit folder-orbit-one" />
        <span className="folder-orbit folder-orbit-two" />
      </div>
      <span className="folder-instruction">Klik folder untuk menjelajahi proyek <Icon name="arrow" size={15} /></span>
    </button>
  );
}

function ProjectCard({ project, onSelect }) {
  return (
    <button className="project-card" type="button" onClick={() => onSelect(project)}>
      <div className="project-card-image"><img src={project.image} alt={project.alt} loading="lazy" /><span className="project-card-arrow"><Icon name="arrow" size={17} /></span></div>
      <div className="project-card-copy"><div className="project-card-meta"><span>{project.category}</span></div><h3>{project.name}</h3><p>{project.description}</p><span className="project-card-open">Lihat detail <Icon name="arrow" size={15} /></span></div>
    </button>
  );
}

function ProjectDetail({ project, onBack }) {
  return (
    <article className="project-detail reveal is-visible" key={project.id}>
      <button className="back-link" type="button" onClick={onBack}><Icon name="back" size={17} /> Kembali ke semua proyek</button>
      <div className="detail-heading"><div><p className="eyebrow">{project.category} <span> / </span> PROJECT DETAILS</p><h3>{project.fullName}</h3></div><a className="button button-primary" href={project.url} target="_blank" rel="noreferrer">Live Demo <Icon name="external" size={15} /></a></div>
      <div className="detail-image-frame"><img src={project.image} alt={project.alt} /></div>
      <div className="detail-copy-grid">
        <div><span className="detail-label">OVERVIEW</span><p>{project.overview}</p><p>{project.description}</p></div>
        <div className="detail-side"><div><span className="detail-label">PERAN</span><p>{project.role}</p></div><div><span className="detail-label">TEKNOLOGI</span><div className="skill-tags detail-tags">{project.stack.map((item) => <span key={item}>{item}</span>)}</div></div><div><span className="detail-label">AREA UTAMA</span><ul>{project.features.map((feature) => <li key={feature}>{feature}</li>)}</ul></div></div>
      </div>
    </article>
  );
}

function Projects() {
  const [view, setView] = useState('folder');
  const [activeProject, setActiveProject] = useState(null);
  const galleryRef = useRef(null);
  useEffect(() => {
    if (view !== 'folder') galleryRef.current?.focus({ preventScroll: true });
  }, [view]);
  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key !== 'Escape') return;
      if (activeProject) { setActiveProject(null); setView('gallery'); }
      else if (view === 'gallery') setView('folder');
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeProject, view]);
  const openGallery = () => { setActiveProject(null); setView('gallery'); };
  const selectProject = (project) => { setActiveProject(project); setView('detail'); };
  const backToGallery = () => { setActiveProject(null); setView('gallery'); };
  return (
    <section className="section projects-section page-width" id="projects">
      <SectionHeading eyebrow="SELECTED WORKS" title="Karya yang" accent="Saya Bangun." description="Setiap proyek adalah ruang untuk bereksperimen, belajar, dan menyusun ide menjadi sesuatu yang nyata." />
      <div className="projects-stage" ref={galleryRef} tabIndex={-1}>
        {view === 'folder' && <ProjectFolder onOpen={openGallery} />}
        {view === 'gallery' && <div className="project-gallery-view"><div className="gallery-toolbar"><div><p className="eyebrow">PROJECT ARCHIVE</p><h3>Folder <span>terbuka.</span></h3></div><button className="back-link" type="button" onClick={() => setView('folder')}><Icon name="back" size={16} /> Tutup folder</button></div><div className="project-grid">{projects.map((project) => <ProjectCard key={project.id} project={project} onSelect={selectProject} />)}</div></div>}
        {view === 'detail' && activeProject && <ProjectDetail project={activeProject} onBack={backToGallery} />}
      </div>
    </section>
  );
}

function Experience() {
  const experiences = [
    { year: '2026 — SEKARANG', role: 'Personal Web Developer', place: 'Proyek Pribadi', description: 'Mengembangkan proyek website pribadi menggunakan HTML, CSS, dan JavaScript. Berfokus pada struktur halaman, desain antarmuka, dan fitur website.' },
    { year: '2026 — SEKARANG', role: 'Web Development Learner', place: 'Pembelajaran Mandiri', description: 'Mempelajari teknologi pengembangan website, meningkatkan kemampuan coding, dan menerapkan pengetahuan melalui latihan serta proyek digital.' },
  ];
  return (
    <section className="section page-width" id="experience">
      <SectionHeading eyebrow="EXPERIENCE" title="Belajar lewat" accent="Proses." description="Pengalaman saya tumbuh dari eksplorasi mandiri dan praktik langsung." />
      <div className="experience-list reveal">{experiences.map((item) => <article className="experience-item" key={item.role}><div className="experience-content"><div className="experience-meta"><span>{item.year}</span><span>{item.place}</span></div><h3>{item.role}</h3><p>{item.description}</p></div></article>)}</div>
    </section>
  );
}

function Education() {
  return (
    <section className="section page-width" id="education">
      <SectionHeading eyebrow="EDUCATION" title="Tempat saya" accent="Bertumbuh." description="Membangun dasar teknologi, logika, dan kreativitas." />
      <article className="education-card glass-panel reveal"><div className="school-logo"><img src="/images/school-logo.webp" alt="Logo SMK Muhammadiyah 1 Pandaan" loading="lazy" /></div><div className="education-info"><p className="eyebrow">2026 — 2029 <span> / </span> VOCATIONAL SCHOOL</p><h3>SMK Muhammadiyah 1 Pandaan</h3><p>Pengembangan Perangkat Lunak dan Gim (PPLG)</p><span className="education-status"><i /> Pelajar</span></div></article>
    </section>
  );
}

function CommentSection() {
  const [comments, setComments] = useState([]);
  const [configured, setConfigured] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [notice, setNotice] = useState('');
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [photo, setPhoto] = useState(null);
  const [website, setWebsite] = useState('');
  const [remaining, setRemaining] = useState(0);

  useEffect(() => {
    let alive = true;
    fetch('/api/comments').then(async (response) => ({ response, data: await response.json() })).then(({ response, data }) => {
      if (!alive) return;
      setConfigured(Boolean(data.configured));
      setComments(Array.isArray(data.comments) ? data.comments : []);
      if (data.retryAfterSeconds) setRemaining(Number(data.retryAfterSeconds));
      if (!response.ok && data.configured) setNotice(data.error || 'Komentar belum dapat dimuat.');
    }).catch(() => { if (alive) { setConfigured(false); setNotice('Layanan komentar belum terhubung ke server.'); } }).finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (remaining <= 0) return undefined;
    const timer = window.setInterval(() => setRemaining((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [remaining > 0]);

  const handlePhoto = (event) => {
    const file = event.target.files?.[0] || null;
    if (!file) { setPhoto(null); return; }
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { setNotice('Foto harus berformat JPG, PNG, atau WebP.'); event.target.value = ''; return; }
    if (file.size > 2 * 1024 * 1024) { setNotice('Ukuran foto maksimal 2 MB.'); event.target.value = ''; return; }
    setPhoto(file);
    setNotice('');
  };

  const submitComment = async (event) => {
    event.preventDefault();
    if (!configured) { setNotice('Komentar belum aktif. Backend perlu dikonfigurasi terlebih dahulu.'); return; }
    if (remaining > 0) { setNotice(`Tunggu ${remaining} detik sebelum mengirim komentar lagi.`); return; }
    setSending(true); setNotice('');
    try {
      let photoDataUrl = null;
      if (photo) photoDataUrl = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result || '')); reader.onerror = () => reject(new Error('Foto tidak dapat dibaca.')); reader.readAsDataURL(photo); });
      const response = await fetch('/api/comments', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, message, photo: photoDataUrl, website }) });
      const data = await response.json();
      if (!response.ok) { if (data.retryAfterSeconds) setRemaining(Number(data.retryAfterSeconds)); throw new Error(data.error || 'Komentar gagal dikirim.'); }
      setNotice(data.message || 'Komentar berhasil dikirim dan menunggu moderasi.');
      setRemaining(Number(data.retryAfterSeconds || 140)); setName(''); setMessage(''); setPhoto(null); setWebsite('');
      const fileInput = document.getElementById('comment-photo'); if (fileInput) fileInput.value = '';
    } catch (error) { setNotice(error.message || 'Terjadi kesalahan. Coba lagi.'); }
    finally { setSending(false); }
  };

  return (
    <div className="comments-panel glass-panel reveal">
      <div className="comments-intro"><p className="eyebrow">GUESTBOOK</p><h3>Tinggalkan <span>cerita.</span></h3><p>Pesan singkat, ide, atau tanggapanmu selalu berarti. Komentar akan ditinjau sebelum ditampilkan.</p><div className="comments-count"><span className="count-dot" /> {comments.length} komentar dipublikasikan</div></div>
      <div className="comments-content">
        <form className="comment-form" onSubmit={submitComment}>
          <label className="honeypot-field" aria-hidden="true">Website<input tabIndex={-1} autoComplete="off" value={website} onChange={(event) => setWebsite(event.target.value)} /></label>
          <label>Nama<input value={name} onChange={(event) => setName(event.target.value)} minLength={2} maxLength={60} placeholder="Nama kamu" required /></label>
          <label>Komentar<textarea value={message} onChange={(event) => setMessage(event.target.value)} minLength={3} maxLength={1000} rows={4} placeholder="Tulis pesan di sini..." required /></label>
          <label className="photo-upload" htmlFor="comment-photo"><span className="photo-upload-icon">+</span><span><strong>{photo ? photo.name : 'Tambah foto profil (opsional)'}</strong><small>JPG, PNG, atau WebP · Maks. 2 MB</small></span><input id="comment-photo" type="file" accept="image/jpeg,image/png,image/webp" onChange={handlePhoto} /></label>
          {notice && <p className={`form-notice ${notice.toLowerCase().includes('berhasil') || notice.toLowerCase().includes('menunggu') ? 'notice-success' : ''}`} role="status">{notice}</p>}
          {remaining > 0 && <p className="cooldown-note">Kirim komentar berikutnya dalam {Math.floor(remaining / 60)}:{String(remaining % 60).padStart(2, '0')}.</p>}
          <button className="button button-primary comment-submit" type="submit" disabled={sending || remaining > 0 || configured === null}>{sending ? 'Mengirim...' : remaining > 0 ? `Tunggu ${remaining} detik` : 'Kirim Komentar'} <Icon name="arrow" size={16} /></button>
          {configured === false && <p className="backend-note">Formulir akan aktif setelah backend komentar dikonfigurasi. Lihat README.md untuk langkah penyiapan Supabase.</p>}
        </form>
        <div className="comment-feed">
          {loading ? <p className="empty-comments">Memuat komentar...</p> : comments.length === 0 ? <p className="empty-comments">Belum ada komentar yang dipublikasikan. Jadilah yang pertama meninggalkan pesan.</p> : comments.map((comment) => <article className="comment-item" key={comment.id}><div className="comment-avatar">{comment.avatar_url ? <img src={comment.avatar_url} alt={`Foto profil ${comment.name}`} loading="lazy" /> : <span>{comment.name?.trim()?.[0]?.toUpperCase() || 'R'}</span>}</div><div><div className="comment-meta"><strong>{comment.name}</strong><time>{new Date(comment.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}</time></div><p>{comment.message}</p></div></article>)}
        </div>
      </div>
    </div>
  );
}

function Contact() {
  const contacts = [
    { label: 'Email', value: 'raditcyper1@gmail.com', href: 'mailto:raditcyper1@gmail.com', icon: 'email' },
    { label: 'Instagram', value: '@xn0ne_404', href: 'https://www.instagram.com/xn0ne_404?cplk=c3lyMWVtdjY5eGdr', icon: 'instagram' },
    { label: 'TikTok', value: '@xenone404', href: 'https://www.tiktok.com/@xenone404?_r=1&_t=ZS-9A557I1qhvT', icon: 'tiktok' },
    { label: 'Telegram', value: 't.me/ditzXT17', href: 'https://t.me/ditzXT17', icon: 'telegram' },
  ];
  return (
    <section className="section page-width contact-section" id="contact">
      <SectionHeading eyebrow="CONTACT & GUESTBOOK" title="Mari" accent="Berkolaborasi." description="Tertarik berdiskusi tentang website, teknologi, atau ide proyek digital? Saya terbuka untuk bertukar ide dan belajar bersama." />
      <div className="contact-links reveal">{contacts.map((contact) => <a className="contact-link" key={contact.label} href={contact.href} target={contact.label === 'Email' ? undefined : '_blank'} rel={contact.label === 'Email' ? undefined : 'noreferrer'}><span className={`contact-brand-icon contact-brand-icon--${contact.icon}`}><BrandIcon name={contact.icon} size={23} /></span><span className="contact-link-text"><small>{contact.label}</small><strong>{contact.value}</strong></span><Icon name="external" size={16} /></a>)}</div>
      <CommentSection />
    </section>
  );
}

function Footer() {
  return <footer className="site-footer page-width"><a className="footer-brand" href="#home">RADIT<span>.</span></a><p>Designed and developed with creativity.</p><span>© 2026 Radit. All rights reserved.</span><a className="back-to-top" href="#home" aria-label="Kembali ke atas"><Icon name="arrow" size={16} /></a></footer>;
}

function PlaylistPanel({ open, onClose }) {
  return (
    <>
      {open && <button className="playlist-scrim" aria-label="Tutup panel playlist" onClick={onClose} />}
      <aside className={`playlist-panel glass-panel ${open ? 'is-open' : ''}`} aria-hidden={!open} aria-label="Spotify playlist">
        <div className="playlist-panel-head"><div><p className="eyebrow">SPOTIFY PLAYLIST</p><h2>Playlist<span>.</span></h2></div><button className="icon-button" type="button" onClick={onClose} aria-label="Tutup playlist"><Icon name="close" size={19} /></button></div>
        <p className="playlist-description">Temani waktu menjelajah karya dan ide baru.</p>
        <div className="spotify-frame"><iframe title="Spotify playlist Radit" src="https://open.spotify.com/embed/playlist/6IVSqu5z6fwknHLj0JcnNE?utm_source=generator&si=66117ad804a64312" width="100%" height="352" frameBorder="0" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" allowFullScreen loading="lazy" /></div>
        <a className="spotify-open-link" href="https://open.spotify.com/playlist/6IVSqu5z6fwknHLj0JcnNE" target="_blank" rel="noreferrer">Buka di Spotify <Icon name="external" size={15} /></a>
      </aside>
    </>
  );
}

function useReveal() {
  useEffect(() => {
    const nodes = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      nodes.forEach((node) => node.classList.add('is-visible'));
      return undefined;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -36px 0px' });
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);
}

export default function App() {
  const [playlistOpen, setPlaylistOpen] = useState(false);
  const path = useMemo(() => window.location.pathname.replace(/\/+$/, '') || '/', []);
  useReveal();
  useEffect(() => {
    const onKeyDown = (event) => { if (event.key === 'Escape') setPlaylistOpen(false); };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);
  if (path === '/admin') return <AdminPage />;
  return (
    <div className="app-shell">
      <MapleAtmosphere />
      <Header onPlaylist={() => setPlaylistOpen(true)} />
      <main className="site-main">
        <Hero />
        <div className="hero-afterline page-width"><span>SCROLL TO EXPLORE</span><i /><span>RADIT PORTFOLIO</span></div>
        <About />
        <Skills />
        <Projects />
        <Experience />
        <Education />
        <Contact />
      </main>
      <Footer />
      <PlaylistPanel open={playlistOpen} onClose={() => setPlaylistOpen(false)} />
    </div>
  );
}
