create extension if not exists pgcrypto;

create table if not exists public.portfolio_comments (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 60),
  message text not null check (char_length(message) between 3 and 1000),
  avatar_url text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now(),
  moderated_at timestamptz
);

create table if not exists public.comment_rate_limits (
  ip_hash text primary key,
  last_submitted_at timestamptz not null
);

alter table public.portfolio_comments enable row level security;
alter table public.comment_rate_limits enable row level security;

-- API accesses these tables through the server-only service-role key.
-- No anonymous policies are intentionally created.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('comment-avatars', 'comment-avatars', true, 2097152, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = excluded.public, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

create or replace function public.submit_portfolio_comment(
  p_name text,
  p_message text,
  p_avatar_url text,
  p_ip_hash text
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  last_time timestamptz;
  wait_seconds integer;
begin
  -- Serialize concurrent requests from the same visitor before checking the 140-second cooldown.
  perform pg_advisory_xact_lock(hashtextextended(p_ip_hash, 0));

  select last_submitted_at into last_time
  from public.comment_rate_limits
  where ip_hash = p_ip_hash
  for update;

  if last_time is not null then
    wait_seconds := ceil(extract(epoch from (last_time + interval '140 seconds' - now())))::integer;
    if wait_seconds > 0 then
      return jsonb_build_object('ok', false, 'retry_after', wait_seconds);
    end if;
  end if;

  insert into public.comment_rate_limits (ip_hash, last_submitted_at)
  values (p_ip_hash, now())
  on conflict (ip_hash) do update set last_submitted_at = excluded.last_submitted_at;

  insert into public.portfolio_comments (name, message, avatar_url, status)
  values (left(trim(p_name), 60), left(trim(p_message), 1000), p_avatar_url, 'pending');

  return jsonb_build_object('ok', true);
end;
$$;

revoke all on function public.submit_portfolio_comment(text, text, text, text) from public, anon, authenticated;
grant execute on function public.submit_portfolio_comment(text, text, text, text) to service_role;
