import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { createClient } from '@supabase/supabase-js';

const BUCKET = 'comment-avatars';
const COOLDOWN_SECONDS = 140;
const MAX_PHOTO_BYTES = 2 * 1024 * 1024;
const MAX_BODY_BYTES = 4 * 1024 * 1024;
const IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
let client;

function send(res, status, payload, extraHeaders = {}) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  for (const [key, value] of Object.entries(extraHeaders)) res.setHeader(key, value);
  res.end(JSON.stringify(payload));
}

function header(req, name) {
  const value = req.headers?.[name.toLowerCase()];
  return Array.isArray(value) ? value.join(', ') : typeof value === 'string' ? value : '';
}

function configured() {
  return Boolean((process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL) && process.env.SUPABASE_SERVICE_ROLE_KEY && process.env.RATE_LIMIT_SECRET && process.env.ADMIN_TOKEN);
}

function supabaseAdmin() {
  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  if (!client) client = createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false } });
  return client;
}

function visitorHash(req) {
  const secret = process.env.RATE_LIMIT_SECRET;
  if (!secret) return null;
  const trusted = header(req, 'x-vercel-forwarded-for') || header(req, 'x-real-ip') || header(req, 'x-forwarded-for').split(',')[0];
  const ip = (trusted || '127.0.0.1').trim();
  return createHmac('sha256', secret).update(ip).digest('hex');
}

function secureEquals(candidate, expected) {
  if (!candidate || !expected) return false;
  const a = Buffer.from(candidate);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

function isAdmin(req) {
  const match = header(req, 'authorization').match(/^Bearer\s+(.+)$/i);
  return Boolean(match && secureEquals(match[1], process.env.ADMIN_TOKEN));
}

async function readBody(req) {
  if (req.body !== undefined && req.body !== null) {
    if (Buffer.isBuffer(req.body)) return JSON.parse(req.body.toString('utf8'));
    if (typeof req.body === 'string') return JSON.parse(req.body);
    if (typeof req.body === 'object') return req.body;
  }
  let total = 0;
  const chunks = [];
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    total += buffer.length;
    if (total > MAX_BODY_BYTES) { const error = new Error('Ukuran permintaan terlalu besar.'); error.statusCode = 413; throw error; }
    chunks.push(buffer);
  }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {};
}

function cleanText(value, max) {
  if (typeof value !== 'string') return '';
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max);
}

function parsePhoto(value) {
  if (!value) return null;
  if (typeof value !== 'string') throw new Error('Foto profil tidak valid.');
  const match = value.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\r\n]+)$/);
  if (!match || !IMAGE_TYPES.has(match[1])) throw new Error('Foto harus berformat JPG, PNG, atau WebP.');
  const mimeType = match[1];
  const buffer = Buffer.from(match[2], 'base64');
  if (!buffer.length || buffer.length > MAX_PHOTO_BYTES) throw new Error('Ukuran foto maksimal 2 MB.');
  const valid = mimeType === 'image/jpeg'
    ? buffer.length > 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff
    : mimeType === 'image/png'
      ? buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
      : buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP';
  if (!valid) throw new Error('Isi file tidak cocok dengan format gambar yang dipilih.');
  const extension = mimeType === 'image/png' ? 'png' : mimeType === 'image/webp' ? 'webp' : 'jpg';
  return { buffer, mimeType, extension };
}

async function retryAfter(supabase, hash) {
  const { data, error } = await supabase.from('comment_rate_limits').select('last_submitted_at').eq('ip_hash', hash).maybeSingle();
  if (error) throw error;
  if (!data) return 0;
  const last = new Date(data.last_submitted_at).getTime();
  if (!Number.isFinite(last)) return 0;
  return Math.max(0, Math.ceil((last + COOLDOWN_SECONDS * 1000 - Date.now()) / 1000));
}

export async function commentsHandler(req, res) {
  if (!configured()) return send(res, 503, { configured: false, comments: [], error: 'Fitur komentar belum dikonfigurasi. Hubungkan Supabase terlebih dahulu.' });
  const supabase = supabaseAdmin();
  const hash = visitorHash(req);
  if (!supabase || !hash) return send(res, 503, { configured: false, comments: [], error: 'Konfigurasi backend belum lengkap.' });

  if (req.method === 'GET') {
    try {
      const [result, wait] = await Promise.all([
        supabase.from('portfolio_comments').select('id,name,message,avatar_url,created_at').eq('status', 'approved').order('created_at', { ascending: false }).limit(50),
        retryAfter(supabase, hash),
      ]);
      if (result.error) throw result.error;
      return send(res, 200, { configured: true, comments: result.data || [], retryAfterSeconds: wait });
    } catch (error) {
      console.error('Comments GET:', error.message);
      return send(res, 503, { configured: true, comments: [], error: 'Komentar belum dapat dimuat. Periksa konfigurasi database.' });
    }
  }

  if (req.method !== 'POST') return send(res, 405, { error: 'Metode tidak diizinkan.' }, { Allow: 'GET, POST' });
  let body;
  try { body = await readBody(req); }
  catch (error) { return send(res, error.statusCode || 400, { error: error.statusCode === 413 ? error.message : 'Data permintaan tidak valid.' }); }
  if (String(body.website || '').trim()) return send(res, 201, { accepted: true, status: 'pending' });

  const name = cleanText(body.name, 60);
  const message = cleanText(body.message, 1000);
  if (name.length < 2) return send(res, 400, { error: 'Nama minimal 2 karakter.' });
  if (message.length < 3) return send(res, 400, { error: 'Komentar minimal 3 karakter.' });
  let photo;
  try { photo = parsePhoto(body.photo); }
  catch (error) { return send(res, 400, { error: error.message }); }

  let uploadedPath = null;
  try {
    const wait = await retryAfter(supabase, hash);
    if (wait > 0) return send(res, 429, { error: `Tunggu ${wait} detik sebelum mengirim komentar lagi.`, retryAfterSeconds: wait }, { 'Retry-After': String(wait) });
    let avatarUrl = null;
    if (photo) {
      uploadedPath = `${hash}/${randomUUID()}.${photo.extension}`;
      const { error } = await supabase.storage.from(BUCKET).upload(uploadedPath, photo.buffer, { contentType: photo.mimeType, cacheControl: '3600', upsert: false });
      if (error) { console.error('Avatar upload:', error.message); return send(res, 502, { error: 'Foto profil gagal diunggah. Coba lagi atau kirim tanpa foto.' }); }
      avatarUrl = supabase.storage.from(BUCKET).getPublicUrl(uploadedPath).data.publicUrl;
    }
    const { data, error } = await supabase.rpc('submit_portfolio_comment', { p_name: name, p_message: message, p_avatar_url: avatarUrl, p_ip_hash: hash });
    if (error) {
      if (uploadedPath) await supabase.storage.from(BUCKET).remove([uploadedPath]);
      console.error('Comment submission:', error.message);
      return send(res, 503, { error: 'Komentar belum dapat disimpan. Pastikan skema Supabase sudah dipasang.' });
    }
    const result = Array.isArray(data) ? data[0] : data;
    if (!result?.ok) {
      if (uploadedPath) await supabase.storage.from(BUCKET).remove([uploadedPath]);
      const seconds = Math.max(1, Number(result?.retry_after) || COOLDOWN_SECONDS);
      return send(res, 429, { error: `Tunggu ${seconds} detik sebelum mengirim komentar lagi.`, retryAfterSeconds: seconds }, { 'Retry-After': String(seconds) });
    }
    return send(res, 201, { accepted: true, status: 'pending', retryAfterSeconds: COOLDOWN_SECONDS, message: 'Komentar berhasil dikirim dan menunggu moderasi.' });
  } catch (error) {
    if (uploadedPath) { try { await supabase.storage.from(BUCKET).remove([uploadedPath]); } catch { /* best-effort cleanup */ } }
    console.error('Comment POST:', error.message);
    return send(res, 500, { error: 'Terjadi kesalahan pada server. Silakan coba kembali.' });
  }
}

export async function adminCommentsHandler(req, res) {
  if (!isAdmin(req)) return send(res, 401, { error: 'Token admin tidak valid.' });
  if (!configured()) return send(res, 503, { error: 'Konfigurasi Supabase belum lengkap.' });
  const supabase = supabaseAdmin();

  if (req.method === 'GET') {
    try {
      const { data, error } = await supabase.from('portfolio_comments').select('id,name,message,avatar_url,created_at,status').eq('status', 'pending').order('created_at', { ascending: true }).limit(100);
      if (error) throw error;
      return send(res, 200, { comments: data || [] });
    } catch (error) { console.error('Admin GET:', error.message); return send(res, 503, { error: 'Antrean komentar belum dapat dimuat.' }); }
  }

  if (req.method === 'PATCH') {
    let body;
    try { body = await readBody(req); } catch { return send(res, 400, { error: 'Data permintaan tidak valid.' }); }
    const { id, status } = body || {};
    if (typeof id !== 'string' || !/^[0-9a-f-]{36}$/i.test(id)) return send(res, 400, { error: 'ID komentar tidak valid.' });
    if (!['approved', 'rejected'].includes(status)) return send(res, 400, { error: 'Status tidak diizinkan.' });
    try {
      const { data, error } = await supabase.from('portfolio_comments').update({ status, moderated_at: new Date().toISOString() }).eq('id', id).eq('status', 'pending').select('id,status,avatar_url').maybeSingle();
      if (error) throw error;
      if (!data) return send(res, 404, { error: 'Komentar tidak ditemukan atau sudah dimoderasi.' });
      if (status === 'rejected' && data.avatar_url) {
        const marker = '/storage/v1/object/public/comment-avatars/';
        const objectPath = data.avatar_url.split(marker)[1];
        if (objectPath) { try { await supabase.storage.from(BUCKET).remove([decodeURIComponent(objectPath)]); } catch (error) { console.error('Avatar cleanup:', error.message); } }
      }
      return send(res, 200, { success: true, comment: { id: data.id, status: data.status } });
    } catch (error) { console.error('Admin PATCH:', error.message); return send(res, 503, { error: 'Status komentar belum dapat diperbarui.' }); }
  }
  return send(res, 405, { error: 'Metode tidak diizinkan.' }, { Allow: 'GET, PATCH' });
}
