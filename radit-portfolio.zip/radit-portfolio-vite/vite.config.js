import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { commentsHandler, adminCommentsHandler } from './server/api-handlers.js';

function localApiPlugin() {
  return {
    name: 'radit-local-api',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const pathname = new URL(req.url || '/', 'http://localhost').pathname;
        if (pathname !== '/api/comments' && pathname !== '/api/admin/comments') return next();
        const handler = pathname === '/api/comments' ? commentsHandler : adminCommentsHandler;
        Promise.resolve(handler(req, res)).catch((error) => {
          console.error('Local API error:', error);
          if (!res.headersSent) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            res.end(JSON.stringify({ error: 'Terjadi kesalahan pada server lokal.' }));
          }
        });
      });
    },
  };
}

export default defineConfig(({ mode }) => {
  Object.assign(process.env, loadEnv(mode, process.cwd(), ''));
  return {
    plugins: [react(), localApiPlugin()],
    server: { host: '0.0.0.0', port: 5173 },
    preview: { host: '0.0.0.0', port: 4173 },
  };
});
