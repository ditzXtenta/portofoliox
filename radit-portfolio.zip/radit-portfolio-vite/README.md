# Radit Portfolio — React + Vite

Portofolio personal Raditya Saputra dengan desain **Dark Cinematic + Maple Autumn**, glassmorphism tipis, folder proyek interaktif, Spotify Embed, dan guestbook komentar.

## Menjalankan website

Persyaratan: Node.js 20.19+ atau 22.12+ dan npm.

1. Ekstrak ZIP proyek.
2. Buka folder proyek di VS Code.
3. Buka Terminal lalu jalankan:

```bash
npm install
npm run dev
```

Buka alamat yang ditampilkan Vite, biasanya `http://localhost:5173`.

Untuk membuat build produksi:

```bash
npm run build
npm run preview
```

## Fitur yang sudah dibuat

- Hero menggunakan poster perkenalan terbaru yang diberikan, termasuk judul, portrait, bingkai, dan speech bubble di dalam gambar. Foto statis; tidak ada hover spotlight. Aset gambar asli tersimpan sebagai `source-assets/aset/poster-perkenalan-radit.png`.
- About, Skills, Projects, Experience, Education, Contact, dan Footer. Penomoran dekoratif yang tidak diperlukan dihapus agar tampilan lebih bersih.
- Folder Projects dengan tiga preview gambar asli. Klik folder untuk membuka galeri; klik salah satu proyek untuk melihat screenshot, ringkasan, peran, teknologi, dan tautan demo.
- Pohon maple diproses dari gambar sumber yang diberikan; beberapa daun dipotong dari gambar yang sama untuk animasi jatuh. Aset asli tetap disimpan di `source-assets/aset/`.
- Daun diletakkan di lapisan latar di belakang konten supaya tidak menutupi teks dan tombol. Animasi mengikuti `prefers-reduced-motion`.
- Panel Playlist memakai Spotify Embed resmi untuk playlist yang diberikan. Panel tidak memaksa autoplay.
- Technical Skills mencakup HTML, CSS, JavaScript, Python, React, dan Vite, masing-masing dengan logo teknologi. Bagian Contact memakai logo Email, Instagram, TikTok, dan Telegram.
- Layout responsif desktop, tablet, dan mobile.
- Guestbook dengan nama, komentar, foto profil opsional, moderasi admin, dan cooldown server-side 140 detik jika Supabase dikonfigurasi.
- Halaman admin komentar tersedia di `/admin`.

## Mengaktifkan backend komentar

Formulir komentar membutuhkan Supabase. Tanpa konfigurasi ini, website tetap bisa dijalankan tetapi komentar belum dapat disimpan atau dimoderasi.

1. Buat project di Supabase.
2. Buka **SQL Editor** dan jalankan isi `supabase/setup.sql`.
3. Salin `.env.example` menjadi `.env.local`.
4. Isi environment variables berikut menggunakan kredensial project milikmu:

```env
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SERVICE_ROLE_KEY
RATE_LIMIT_SECRET=CREATE_A_LONG_RANDOM_SECRET
ADMIN_TOKEN=CREATE_A_DIFFERENT_LONG_RANDOM_ADMIN_TOKEN
```

5. Restart Vite setelah menyimpan `.env.local`.

**Keamanan:** jangan menambahkan awalan `VITE_` pada variabel rahasia. Jangan membagikan `SUPABASE_SERVICE_ROLE_KEY` atau `ADMIN_TOKEN`, dan jangan commit `.env.local` ke Git.

### Moderasi komentar

- Buka `/admin`.
- Masukkan `ADMIN_TOKEN`.
- Muat antrean komentar yang berstatus `pending`.
- Pilih Setujui atau Tolak.
- Hanya komentar yang disetujui yang muncul di halaman publik.
- Cooldown 140 detik ditegakkan lagi oleh fungsi database, bukan hanya oleh timer frontend.

Jika foto avatar ditambahkan, gambar JPG, PNG, atau WebP maksimal 2 MB disimpan pada bucket `comment-avatars`.

## Deploy ke Vercel

1. Unggah folder proyek ke repository Git.
2. Impor repository ke Vercel.
3. Gunakan build command `npm run build` dan output directory `dist`.
4. Tambahkan environment variables server yang sama pada pengaturan project Vercel.
5. Jalankan `supabase/setup.sql` pada Supabase sebelum mengaktifkan komentar.
6. Deploy dan uji URL utama, `/admin`, panel Spotify, folder proyek, detail proyek, dan komentar.

API serverless berada di `api/`. `vercel.json` mengatur build dan rewrite halaman admin.

## Aset

- `public/images/hero-composition.webp`: komposisi Hero dari poster perkenalan terbaru yang diberikan, dioptimalkan untuk web.
- `public/images/beruang.webp`, `payment.webp`, `our-gallery.webp`: screenshot proyek yang diberikan.
- `public/images/maple-tree.png`: pohon maple dengan latar kotak-kotak yang diproses menjadi transparan.
- `public/images/maple-leaves/`: potongan daun dari gambar pohon yang sama.
- `source-assets/aset/`: aset asli yang diunggah, termasuk poster perkenalan terbaru.

Catatan: periksa tampilan pohon di browser setelah deploy. Gambar sumber merupakan JPEG dengan latar papan catur, sehingga pemisahan transparansi dapat menyisakan sedikit detail tepi pada beberapa daun.
